import { useEffect, useRef, useState } from "react";
import Sidebar, { TocItem } from "./components/Sidebar";
import Header from "./components/Header";
import Markdown from "./components/Markdown";
import guideContent from "./content/guide.md?raw";

const BADGES = [
  "Azure Linux 3.0",
  "Kubernetes v1.34 (kubeadm v1beta4)",
  "Cilium eBPF + WireGuard",
  "gVisor / Kata sandboxing",
  "CIS + NSA/CISA hardened",
  "Kyverno policy-as-code",
];

export default function App() {
  const [toc, setToc] = useState<TocItem[]>([]);
  const [activeId, setActiveId] = useState<string>("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  // Build the table of contents from the actually-rendered headings so it is
  // always in sync with the slugs rehype-slug generates.
  useEffect(() => {
    const container = contentRef.current;
    if (!container) return;

    const headingEls = Array.from(
      container.querySelectorAll<HTMLHeadingElement>("h2[id], h3[id]")
    );
    const items: TocItem[] = headingEls.map((el) => ({
      id: el.id,
      text: el.textContent || "",
      level: el.tagName === "H3" ? 3 : 2,
    }));
    setToc(items);

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((e) => e.isIntersecting);
        if (visible.length > 0) {
          const top = visible.reduce((a, b) =>
            a.boundingClientRect.top < b.boundingClientRect.top ? a : b
          );
          setActiveId(top.target.id);
        }
      },
      { rootMargin: "-90px 0px -70% 0px", threshold: [0, 1] }
    );

    headingEls.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const handleDownload = () => {
    const blob = new Blob([guideContent], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "hardened-kubernetes-azure-linux-agentic-guide.md";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      <div className="flex">
        <Sidebar
          items={toc}
          activeId={activeId}
          open={sidebarOpen}
          onNavigate={() => setSidebarOpen(false)}
        />

        {sidebarOpen && (
          <div
            className="fixed inset-0 z-30 bg-black/60 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        <div className="flex min-h-screen flex-1 flex-col lg:pl-0">
          <Header onMenuClick={() => setSidebarOpen((v) => !v)} onDownload={handleDownload} />

          <main className="flex-1">
            {/* Hero */}
            <section className="relative overflow-hidden border-b border-slate-800 bg-[radial-gradient(circle_at_top_left,rgba(99,102,241,0.25),transparent_45%),radial-gradient(circle_at_bottom_right,rgba(6,182,212,0.18),transparent_45%)] px-4 py-14 sm:px-8 lg:px-12">
              <div className="mx-auto max-w-4xl">
                <p className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-indigo-400">
                  Enterprise Reference Architecture
                </p>
                <h1 className="text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl">
                  Hardened Kubernetes on Azure Linux for Agentic AI Workloads
                </h1>
                <p className="mt-4 max-w-2xl text-base leading-7 text-slate-400">
                  A meticulously researched, source-validated deployment guide for a two-node
                  (control-plane + worker), CIS/NSA-CISA-aligned Kubernetes cluster — purpose-built
                  to run autonomous AI agents safely in production.
                </p>
                <div className="mt-6 flex flex-wrap gap-2">
                  {BADGES.map((b) => (
                    <span
                      key={b}
                      className="rounded-full border border-slate-700 bg-slate-900/60 px-3 py-1 text-xs font-medium text-slate-300"
                    >
                      {b}
                    </span>
                  ))}
                </div>
                <div className="mt-8 flex flex-wrap gap-3">
                  <a
                    href="#1-executive-summary--design-principles"
                    className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-indigo-950/50 transition hover:bg-indigo-500"
                  >
                    Start reading →
                  </a>
                  <button
                    onClick={handleDownload}
                    className="rounded-md border border-slate-700 bg-slate-900 px-4 py-2 text-sm font-semibold text-slate-200 transition hover:bg-slate-800"
                  >
                    Download full guide (.md)
                  </button>
                </div>
              </div>
            </section>

            {/* Content */}
            <div className="mx-auto max-w-4xl px-4 py-10 sm:px-8 lg:px-12">
              <div ref={contentRef} className="pb-24">
                <Markdown content={guideContent} />
              </div>
            </div>
          </main>

          <footer className="border-t border-slate-800 px-4 py-6 text-center text-xs text-slate-600 sm:px-8">
            Built as a research-backed reference deliverable. Always re-validate versions and
            package URLs against upstream sources before real-world deployment.
          </footer>
        </div>
      </div>
    </div>
  );
}
