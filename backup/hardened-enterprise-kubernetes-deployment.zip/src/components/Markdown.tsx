import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeSlug from "rehype-slug";
import CodeBlock from "./CodeBlock";
import type { Components } from "react-markdown";

const components: Components = {
  h1: ({ children, ...props }) => (
    <h1
      className="mb-6 mt-2 scroll-mt-24 border-b border-slate-800 pb-4 text-3xl font-bold tracking-tight text-white sm:text-4xl"
      {...props}
    >
      {children}
    </h1>
  ),
  h2: ({ children, ...props }) => (
    <h2
      className="mb-4 mt-12 scroll-mt-24 border-b border-slate-800 pb-2 text-2xl font-bold tracking-tight text-white"
      {...props}
    >
      {children}
    </h2>
  ),
  h3: ({ children, ...props }) => (
    <h3 className="mb-3 mt-8 scroll-mt-24 text-xl font-semibold text-white" {...props}>
      {children}
    </h3>
  ),
  h4: ({ children, ...props }) => (
    <h4 className="mb-2 mt-6 scroll-mt-24 text-base font-semibold text-indigo-300" {...props}>
      {children}
    </h4>
  ),
  p: ({ children, ...props }) => (
    <p className="my-4 leading-7 text-slate-300" {...props}>
      {children}
    </p>
  ),
  a: ({ children, href, ...props }) => (
    <a
      href={href}
      className="font-medium text-indigo-400 underline decoration-indigo-500/40 underline-offset-2 hover:text-indigo-300"
      {...props}
    >
      {children}
    </a>
  ),
  ul: ({ children, ...props }) => (
    <ul className="my-4 list-disc space-y-1.5 pl-6 text-slate-300 marker:text-indigo-500" {...props}>
      {children}
    </ul>
  ),
  ol: ({ children, ...props }) => (
    <ol className="my-4 list-decimal space-y-1.5 pl-6 text-slate-300 marker:text-indigo-400" {...props}>
      {children}
    </ol>
  ),
  li: ({ children, ...props }) => (
    <li className="leading-7" {...props}>
      {children}
    </li>
  ),
  blockquote: ({ children, ...props }) => (
    <blockquote
      className="my-5 rounded-r-md border-l-4 border-indigo-500 bg-indigo-500/5 py-2 pl-4 pr-3 text-slate-300 [&>p]:my-1"
      {...props}
    >
      {children}
    </blockquote>
  ),
  hr: (props) => <hr className="my-10 border-slate-800" {...props} />,
  strong: ({ children, ...props }) => (
    <strong className="font-semibold text-white" {...props}>
      {children}
    </strong>
  ),
  table: ({ children, ...props }) => (
    <div className="my-6 overflow-x-auto rounded-lg border border-slate-800">
      <table className="w-full border-collapse text-sm" {...props}>
        {children}
      </table>
    </div>
  ),
  thead: ({ children, ...props }) => (
    <thead className="bg-slate-800/70 text-left text-xs uppercase tracking-wide text-slate-400" {...props}>
      {children}
    </thead>
  ),
  th: ({ children, ...props }) => (
    <th className="border-b border-slate-800 px-4 py-2.5 font-semibold" {...props}>
      {children}
    </th>
  ),
  td: ({ children, ...props }) => (
    <td className="border-b border-slate-800/70 px-4 py-2.5 align-top text-slate-300" {...props}>
      {children}
    </td>
  ),
  code: ({ className, children, ...props }) => {
    const match = /language-(\w+)/.exec(className || "");
    const isInline = !match;
    if (isInline) {
      return (
        <code
          className="rounded bg-slate-800 px-1.5 py-0.5 font-mono text-[0.85em] text-amber-300"
          {...props}
        >
          {children}
        </code>
      );
    }
    return (
      <CodeBlock language={match ? match[1] : ""} value={String(children).replace(/\n$/, "")} />
    );
  },
  pre: ({ children }) => <>{children}</>,
};

export default function Markdown({ content }: { content: string }) {
  return (
    <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeSlug]} components={components}>
      {content}
    </ReactMarkdown>
  );
}
