import { useMemo, useState } from "react";

export interface TocItem {
  id: string;
  text: string;
  level: number;
}

interface SidebarProps {
  items: TocItem[];
  activeId: string;
  open: boolean;
  onNavigate: () => void;
}

export default function Sidebar({ items, activeId, open, onNavigate }: SidebarProps) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    if (!query.trim()) return items;
    const q = query.toLowerCase();
    return items.filter((i) => i.text.toLowerCase().includes(q));
  }, [items, query]);

  return (
    <aside
      className={`fixed inset-y-0 left-0 z-40 w-72 shrink-0 transform border-r border-slate-800 bg-slate-950/95 backdrop-blur transition-transform duration-200 lg:static lg:z-auto lg:translate-x-0 lg:bg-slate-950 ${
        open ? "translate-x-0" : "-translate-x-full"
      }`}
    >
      <div className="flex h-full flex-col">
        <div className="flex items-center gap-2 border-b border-slate-800 px-4 py-4">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-500 text-sm font-bold text-white">
            K8s
          </div>
          <div>
            <p className="text-sm font-semibold text-white leading-tight">Hardened K8s</p>
            <p className="text-[11px] text-slate-500 leading-tight">on Azure Linux</p>
          </div>
        </div>

        <div className="border-b border-slate-800 p-3">
          <div className="relative">
            <svg
              className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-slate-500"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M9 3.5a5.5 5.5 0 100 11 5.5 5.5 0 000-11zM2 9a7 7 0 1112.452 4.391l3.328 3.329a.75.75 0 11-1.06 1.06l-3.329-3.328A7 7 0 012 9z"
                clipRule="evenodd"
              />
            </svg>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Filter sections…"
              className="w-full rounded-md border border-slate-800 bg-slate-900 py-1.5 pl-8 pr-3 text-xs text-slate-200 placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none"
            />
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto px-2 py-3 text-sm">
          <ul className="space-y-0.5">
            {filtered.map((item) => (
              <li key={item.id}>
                <a
                  href={`#${item.id}`}
                  onClick={onNavigate}
                  className={`block truncate rounded-md px-3 py-1.5 transition ${
                    item.level === 3 ? "ml-3 text-[13px]" : "text-sm"
                  } ${
                    activeId === item.id
                      ? "bg-indigo-500/15 font-medium text-indigo-300"
                      : "text-slate-400 hover:bg-slate-800/60 hover:text-slate-200"
                  }`}
                >
                  {item.text}
                </a>
              </li>
            ))}
            {filtered.length === 0 && (
              <li className="px-3 py-2 text-xs text-slate-600">No matching sections</li>
            )}
          </ul>
        </nav>

        <div className="border-t border-slate-800 p-3 text-[11px] text-slate-600">
          Enterprise deployment guide · validated against 2025–2026 sources
        </div>
      </div>
    </aside>
  );
}
