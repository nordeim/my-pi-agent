# Skills Used — Archive Manifest

**Archive created:** 2026-08-06  
**Session:** web-d1721985-0e4e-4266-8bee-8a68ad9734c5  
**Task:** Validation review of `react-markdown-report` v1.0.1 + design of `markdown-to-web` v2.0.0 skill  
**Deliverable produced:** `/home/z/my-project/download/markdown-to-web-SKILL.{md,pdf,html}`

## Skill included

| Skill | Path in archive | Loaded via | Used for |
|-------|-----------------|------------|----------|
| `pdf` | `pdf/` | `Skill(command="pdf")` | Rendering the `.md` deliverable to a typeset PDF |

## Scripts from `pdf/` actually executed this session

| Script | Purpose |
|--------|---------|
| `pdf/scripts/poster_validate.py check-html` | Pre-render validation of `markdown-to-web-SKILL.html` (passed: 0 errors, 0 warnings) |
| `pdf/scripts/html2pdf-next.js` | HTML → PDF via Playwright + Paged.js (44 pages, 806 KB) |
| `pdf/scripts/pdf.py meta.set` / `meta.get` | Set and verify PDF metadata (Title, Author, Creator, Subject) |
| `pdf/scripts/pdf_qa.py` | Post-render PDF quality check (PASS, 27 minor warnings) |

## Skill files NOT executed but loaded into context

The full `pdf/SKILL.md` routing file was read. The following referenced files were not opened this session because the route was light/standard and the briefs (report.md, creative-fixed-canvas.md, etc.) were not needed for a markdown→PDF conversion via `html2pdf-next.js`:

- `pdf/briefs/*.md` (8 files)
- `pdf/typesetting/*.md` (9 files)
- `pdf/configs/*.md` (3 files)

They are included in the archive for completeness so the skill is re-installable as a unit.

## Skill files NOT included in this archive

- **`pdf/node_modules/`** — 22 MB of dependencies (pagedjs, playwright, pdf-lib, etc.). Excluded because it is fully reproducible from `pdf/package.json` + `pdf/package-lock.json` via `npm install`. Re-inflate with: `cd pdf && npm install`.
- **`__pycache__/` / `*.pyc`** — Python bytecode cache, regenerated on first run.

## Skills NOT used this session (not archived)

The following skills exist in `/home/z/my-project/skills/` but were NOT loaded or executed during this task:

- `charts`, `docx`, `xlsx`, `pptx`, `fullstack-dev`, `ASR`, `LLM`, `TTS`, `VLM`, `image-generation`, `image-edit`, `image-search`, `web-reader`, `web-search`, `video-understand`, `agent-browser`, `skill-creator`, `skill-finder-cn`, `task-review`, and others.

Only `pdf` was actually invoked. If you need a different skill's source, it lives at `/home/z/my-project/skills/<name>/`.

## How to rehydrate

```bash
# Extract
tar -xzf skills-used.tar.gz -C /path/to/skills/

# Reinstall node deps for the pdf skill
cd /path/to/skills/pdf
npm install

# Verify
node scripts/html2pdf-next.js --help
python3 scripts/pdf.py env.check
```
